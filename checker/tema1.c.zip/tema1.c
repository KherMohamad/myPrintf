#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

static int write_stdout(const char *token, int length)
{
	int rc;
	int bytes_written = 0;

	do {
		rc = write(1, token + bytes_written, length - bytes_written);
		if (rc < 0)
			return rc;

		bytes_written += rc;
	} while (bytes_written < length);

	return bytes_written;
}

 void swap(char *x, char *y) {
	char t = *x; *x = *y; *y = t;
}

// function to reverse buffer[i..j]
char* reverse(char *buffer, int i, int j)
{
	while (i < j)
		swap(&buffer[i++], &buffer[j--]);

	return buffer;
}

// Iterative function to implement itoa() function in C

  char *itoa(unsigned int num, int base) 
{ 
	static char Representation[]= "0123456789abcdef";
	static char buffer[50]; 
	char *ptr; 
	
	ptr = &buffer[49]; 
	*ptr = '\0'; 
	
	do 
	{ 
		*--ptr = Representation[num%base]; 
		num /= base; 
	}while(num != 0); 
	
	return(ptr); 
}


int iocla_printf(const char *format, ...) {
	char formatted[10000];
	va_list args;
	va_start(args, format);
	int iFormatted = 0;
	int nr;
	unsigned int uNr;
	char buffer[12];
	for (int i = 0; i < strlen(format); i++) {
		if (format[i] != '%') {
			formatted[iFormatted] = format[i];
			iFormatted++; 
		}  else {
			switch(format[i + 1]) {
				case 'd':
				    nr = va_arg(args, int);
				    if (nr < 0) {
				    	formatted[iFormatted++] = '-';
				    	nr *= -1;
				    }
				    strcpy(buffer, itoa(nr, 10));
				    memcpy(formatted + iFormatted, buffer, strlen(buffer) + 1);
				    iFormatted += strlen(buffer);
				    i++;
				    break;

				case 'u':
					uNr = va_arg(args, unsigned int);
					strcpy(buffer, itoa(uNr, 10));
					memcpy(formatted + iFormatted, buffer, strlen(buffer) + 1);
					iFormatted += strlen(buffer);
					i++;
					break;
				case 'x':
					uNr = va_arg(args, unsigned int);
					strcpy(buffer, itoa(uNr, 16));
					memcpy(formatted + iFormatted, buffer, strlen(buffer) + 1);
					iFormatted += strlen(buffer);
					i++;
					break;
				case 'c':
					nr = va_arg(args, int);
					formatted[iFormatted++] = nr;
					i++;
					break;

				case 's':
					strcpy(buffer, va_arg(args, char *));
					memcpy(formatted + iFormatted, buffer, strlen(buffer) + 1);
					iFormatted += strlen(buffer);
					i++;
					break;	
				default:
					formatted[iFormatted++] = format[i];
					i++; 		         

			}
		}
	}
	formatted[iFormatted] = 0;
	

	va_end(args);

	return write_stdout(formatted, iFormatted);
}
